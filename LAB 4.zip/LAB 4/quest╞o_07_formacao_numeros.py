n = int(input())

