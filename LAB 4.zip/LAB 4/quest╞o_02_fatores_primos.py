n = int(input())
divisor = 2

while n > 1:
    while n % divisor == 0:
        print (divisor)
        n//= divisor
    divisor += 1
