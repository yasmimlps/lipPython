b = int(input())
y=0
for n in range(1, b+1 ):
    x = (n**(1/n))
    y += x
print(y)