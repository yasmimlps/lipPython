n = int(input())
contador = 0
a = 0
b = 1
while contador < n:
    seguinte = a + b
    print(a, b, seguinte)
    a, b = b, seguinte
    contador += 1