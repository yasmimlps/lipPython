entrada = (int(input()))
n = entrada
soma = 0
while n:
    soma+= n%10
    print(soma)
    n //= 10
    print(n)

print(f"A soma dos dígitos de {entrada} = {soma}")